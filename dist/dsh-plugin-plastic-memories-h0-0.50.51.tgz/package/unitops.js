/**
 * PM · 单元序号寻址。
 *
 * plasticize 的 ops[].positions：当前世代单元序号（0 起），支持
 * "unit 3"、"unit 3 to 7"、"this"。一个 op 里的多个 selector 按单元顺序
 * 展开：前段隐藏，new_text 落在最后一个单元。
 *
 * @module dsh-plugin-plastic-memories-h0/unitops
 */

import { currentUnits, isThisSelector, parseUnitRange } from './units.js';
import { normalizeOp, isLastSetMacro } from './opshape.js';
import { findLastPendingSet } from './pending.js';

/** 找出 this 指向的单元：承载本次声明的那条 assistant 单元。 */
function unitForHere(units, here) {
  if (here === undefined || here === null) return undefined;
  const seqs = [here.thisSeq, here.thisEndSeq].filter(Number.isSafeInteger);
  return units.find((unit) => seqs.some((seq) => unit.seqs.includes(seq)));
}

/** 把一组单元序号合并成连续区间。 */
function unitRanges(numbers) {
  const sorted = [...new Set(numbers)].sort((left, right) => left - right);
  const ranges = [];
  for (const n of sorted) {
    const last = ranges[ranges.length - 1];
    if (last !== undefined && n === last[1] + 1) last[1] = n;
    else ranges.push([n, n]);
  }
  return ranges;
}

/**
 * 把 ops 里的宏元素替换成待决 set 的 ops（原地展开，顺序保持）。
 * @param {object} session
 * @param {Array<object>} ops
 * @param {{replayed?: boolean}} options
 * @returns {Array<object>} 展开后的 ops。
 */
function expandLastSetMacro(session, ops, options) {
  const marks = [];
  for (let index = 0; index < ops.length; index += 1) if (isLastSetMacro(ops[index])) marks.push(index);
  if (marks.length === 0) return ops;
  if (marks.length > 1) throw new Error('"the last plasticize(set)" may appear only once in ops');
  if (options.replayed === true) throw new Error('the pending set itself references "the last plasticize(set)"; fix that set instead');
  const pending = findLastPendingSet(session);
  if (pending === undefined) throw new Error('there is no pending plasticize(set) to replay; pass the ops explicitly');
  const index = marks[0];
  return [...ops.slice(0, index), ...pending.ops, ...ops.slice(index + 1)];
}

/**
 * 解析 positions 形式的 ops。
 * @param {object} session - 目标会话。
 * @param {Array<object>} rawOps - 原始 ops。
 * @param {{thisSeq?: number, thisEndSeq?: number}} here - this 定位点。
 * @returns {Array<{op: object, shadowed: number[]}>} 与 resolveOps 同形。
 */
export function resolveUnitOps(session, rawOps, here, options = {}) {
  if (!Array.isArray(rawOps) || rawOps.length === 0) throw new Error('ops must be a non-empty array');
  // `{ "the last plasticize(set)" }` 是 ops 里的一个宏元素：把它替换成待决 set 的 ops 数组。
  // 它只能出现一次，且不能出现在 set 自己身上（由工具层拒绝）。
  const expanded = expandLastSetMacro(session, rawOps, options);
  const units = currentUnits(session);
  const thisUnit = unitForHere(units, here);
  const out = [];
  for (let index = 0; index < expanded.length; index += 1) {
    // 与命令路径共用同一个 op 校验器（opshape.js），不在这里重复一套规则。
    const raw = normalizeOp(expanded[index], index);
    const selector = raw.positions;
    const newText = raw.new_text;
    const picked = [];
    if (isThisSelector(selector)) {
      if (thisUnit === undefined) throw new Error('op #' + index + ': this is not resolvable');
      picked.push(thisUnit.n);
    } else {
      try { picked.push(...parseUnitRange(selector)); } catch (error) { throw new Error('op #' + index + ': ' + error.message); }
    }
    for (const n of picked) if (n < 0 || n >= units.length) throw new Error('op #' + index + ': unit ' + n + ' is out of range (0..' + (units.length - 1) + ')');
    const ranges = unitRanges(picked);
    if (ranges.length === 0) throw new Error('op #' + index + ' selects no units');
    for (let r = 0; r < ranges.length; r += 1) {
      const [start, end] = ranges[r];
      const selected = units.slice(start, end + 1);
      const shadowed = selected.flatMap((unit) => unit.seqs);
      out.push({
        op: { ...raw, new_text: r === ranges.length - 1 ? newText : '', positions: undefined },
        shadowed,
      });
    }
  }
  return out;
}
