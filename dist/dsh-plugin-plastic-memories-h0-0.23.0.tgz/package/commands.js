/**
 * Plastic Memories — 用户侧 slash 命令。
 *
 * 用户命令是工具之外的**另一个调用者**，不维护第二套投影逻辑：
 *
 *   /plasticize <区间> <替代文本>   直接执行一次稳定化（不经过模型，不写 set 预览）
 *   /lock <区间>                    把区间内消息设为安全区：任何 plasticize 操作都不能命中
 *
 * 语法刻意保持极简、**不做引号解析**：
 *   - 区间是第一个参数，不含空格（如 `(3,4)`、`[3,4]`、`3`）；
 *   - 其余内容原样作为替代文本：写了引号，引号就属于替代文本；
 *   - 不需要 JSON，不需要 option。
 *
 * 用户命令没有「承载步骤」，因此区间不能用 `this`（engine 会明确拒绝）。
 *
 * @module dsh-plugin-plastic-memories-h0/commands
 */

import { executeUserCommand, lockInterval } from './engine.js';

/** /plasticize 的用法提示。 */
const PLASTICIZE_HINT = '<区间> <替代文本>';

/** /lock 的用法提示。 */
const LOCK_HINT = '<区间>';

/**
 * 解析 /plasticize 输入：恰好两个参数，空格分隔，原样读取替代文本。
 * @param {string} rawInput - 命令名之后的全部输入。
 * @returns {{ops: Array<object>, option: 'execute'}} 工具同款参数。
 * @throws {Error} 参数个数或格式不对时。
 */
export function parsePlasticizeInput(rawInput) {
  const text = String(rawInput ?? '').replace(/^\s+/, '');
  const match = /^(\S+)[ \t]+([\s\S]*)$/.exec(text);
  if (match === null) {
    throw new Error('用法：/plasticize ' + PLASTICIZE_HINT + '（两个参数，空格分隔；替代文本为空时用 /plasticize 工具）');
  }
  const interval = match[1];
  const newText = match[2];
  if (newText.length === 0) {
    throw new Error('缺少替代文本。用法：/plasticize ' + PLASTICIZE_HINT);
  }
  return {
    ops: [{ spans: [interval], new_text: newText }],
    option: 'execute',
  };
}

/**
 * 解析 /lock 输入：一个区间。
 * @param {string} rawInput - 命令名之后的全部输入。
 * @returns {string} 区间文本。
 * @throws {Error} 输入为空或含空格时。
 */
export function parseLockInput(rawInput) {
  const text = String(rawInput ?? '').trim();
  if (text.length === 0) throw new Error('用法：/lock ' + LOCK_HINT);
  if (/\s/.test(text)) throw new Error('区间不能含空格。用法：/lock ' + LOCK_HINT);
  return text;
}

/**
 * 把用户命令接到 `ctx.commands`（可选服务：没有命令面板的 profile 里安静缺席）。
 * @param {object} ctx - 插件上下文（preset/agent 作用域 —— 命令因此只在该作用域可见）。
 * @param {object} [logger] - 日志器。
 */
export function registerCommands(ctx, logger) {
  ctx.inject(['commands'], (commandCtx) => {
    const fail = (error) => ({ kind: 'error', text: String(error?.message ?? error) });
    commandCtx.commands.register({
      name: 'plasticize',
      description: '直接改写会话投影：/plasticize <区间> <替代文本>',
      input: { hint: PLASTICIZE_HINT },
      recordInput: false,
      handler: ({ agent, rawInput }) => {
        const session = agent?.session;
        if (session === undefined || session === null) return fail(new Error('这条命令需要一个会话'));
        try {
          const { ops, option } = parsePlasticizeInput(rawInput);
          const result = executeUserCommand(session, ops, option, logger);
          return { kind: 'success', text: result.text };
        } catch (error) {
          return fail(error);
        }
      },
    });
    commandCtx.commands.register({
      name: 'lock',
      description: '锁定一个区间：之后任何 plasticize 操作都不能命中它',
      input: { hint: LOCK_HINT },
      recordInput: false,
      handler: ({ agent, rawInput }) => {
        const session = agent?.session;
        if (session === undefined || session === null) return fail(new Error('这条命令需要一个会话'));
        try {
          const interval = parseLockInput(rawInput);
          const result = lockInterval(session, interval);
          return {
            kind: 'success',
            text: '已锁定 ' + String(result.count) + ' 条消息（区间 ' + interval + '）。之后的 plasticize 操作命中这些消息会被拒绝。',
          };
        } catch (error) {
          return fail(error);
        }
      },
    });
  });
}
