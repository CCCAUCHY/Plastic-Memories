/**
 * Plastic Memories — 用户侧 slash 命令。
 *
 * 用户命令只是工具的**另一个调用者**，不维护第二套投影逻辑：
 *
 *   /plasticize <区间> <替代文本>   直接执行一次稳定化
 *   /lock   <区间|all|this>         把目标纳入安全区（this = 下一条用户消息）
 *   /unlock <区间|all>              把目标移出安全区（没有 this：不存在的消息本来就不会被锁）
 *
 * 安全区遵循「会话日志是唯一事实源」：
 *   - 每次命令向日志追加一条 plugin record（ignorable，不进入 surface/上下文）；
 *   - 之后永不修改；
 *   - 当前安全区 = 按出现顺序回放所有安全区记录，lock 叠加、unlock 扣除；
 *   - 引擎与 UI 都是纯函数，不保存任何内存锁。
 *
 * `this` 形式（/lock this 换行后写用户消息正文）：
 *   - 必须换行，正文非空；不换行视为非法参数；
 *   - 命令会追加安全区记录，并把正文作为一条 user 消息 followup 给 agent；
 *   - 回放时该记录匹配其后的那条 user 消息。
 *
 * 推理进行中（agent.status !== 'idle'）不允许执行 /plasticize 以及区间/all 形式的 /lock、/unlock；
 * this 形式例外：消息尚未存在，模型无从命中，私有事件先于消息进入上下文，本身没有竞态。
 *
 * @module dsh-plugin-plastic-memories-h0/commands
 */

import { appendSafetyRecord, clearUserProjections, queueUserProjection, resolveLockSeqs } from './engine.js';

const PLASTICIZE_HINT = '<区间> <替代文本>';
const SAFETY_HINT = '<区间|all|this>';
const UNLOCK_HINT = '<区间|all>';

/**
 * 解析 /plasticize 输入。三种形式：
 *   /plasticize clear
 *   /plasticize hide <区间>
 *   /plasticize <区间> <替代文本>   （替代文本原样保留，可含换行）
 * @param {string} rawInput - 命令名之后的全部输入。
 * @returns {{action:'clear'}|{action:'queue', interval:string, newText:string, hide:boolean}}
 */
export function parsePlasticizeCommand(rawInput) {
  const text = String(rawInput ?? '').replace(/^\s+/, '');
  if (text === 'clear') return { action: 'clear' };
  if (/\bhide\b/.test(text) && text.startsWith('hide')) {
    const match = /^hide[ \t]+(\S+)[ \t]*$/.exec(text);
    if (match === null) throw new Error('hide 后必须是一个合法区间。例如：/plasticize hide [3,4]');
    return { action: 'queue', interval: match[1], newText: '', hide: true };
  }
  const match = /^(\S+)[ \t\r\n]+([\s\S]*)$/.exec(text);
  if (match === null) {
    throw new Error('缺少替代文本。隐藏请用 /plasticize hide <区间>；清空队列请用 /plasticize clear。');
  }
  return { action: 'queue', interval: match[1], newText: match[2], hide: false };
}
/**
 * 解析 /lock 或 /unlock 的输入。
 * @param {string} rawInput - 命令名之后的全部输入。
 * @returns {{mode: 'range'|'all'|'this', interval?: string, body?: string}}
 */
export function parseSafetyCommand(rawInput, op = 'lock') {
  const text = String(rawInput ?? '').replace(/^\s+/, '');
  if (text.length === 0) throw new Error('用法：/' + op + ' ' + (op === 'unlock' ? UNLOCK_HINT : SAFETY_HINT));
  if (text === 'all') return { mode: 'all' };
  if (text.startsWith('this')) {
    if (op === 'unlock') throw new Error('/unlock 不支持 this：消息尚未存在时本来就不在安全区。');
    const match = /^this[ \t]*\r?\n([\s\S]+)$/.exec(text);
    if (match === null || match[1].trim().length === 0) {
      throw new Error('this 后必须换行并输入用户消息正文（不换行是非法参数）。例如：/lock this\n你的消息');
    }
    return { mode: 'this', body: match[1] };
  }
  if (/\s/.test(text)) throw new Error('区间不能含空格。用法：/' + op + ' ' + (op === 'unlock' ? UNLOCK_HINT : SAFETY_HINT));
  return { mode: 'range', interval: text };
}

/** 把 this 的正文作为用户消息发给 agent（官方 createUserMessage；不可用时退化为等价对象）。 */
async function followupUserBody(agent, body) {
  let message;
  try {
    const module = await import('@deepseek-ai/dsh-llm');
    if (typeof module.createUserMessage === 'function') {
      message = module.createUserMessage({ content: [{ type: 'text', text: body }], source: { kind: 'user' } });
    }
  } catch {
    message = undefined;
  }
  if (message === undefined) {
    message = {
      id: 'pm-this-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10),
      role: 'user',
      content: [{ type: 'text', text: body }],
      source: { kind: 'user' },
    };
  }
  agent.followup(message);
}

/**
 * 把用户命令接到 `ctx.commands`（可选服务：没有命令面板的 profile 里安静缺席）。
 * @param {object} ctx - 插件上下文（preset/agent 作用域 —— 命令因此只在该作用域可见）。
 * @param {object} [logger] - 日志器。
 */
export function registerCommands(ctx, logger) {
  ctx.inject(['commands'], (commandCtx) => {
    const fail = (error) => ({ kind: 'error', text: String(error?.message ?? error) });
    const busy = (agent) => agent !== undefined && agent !== null && agent.status !== 'idle';
    const busyError = () => new Error('正在推理中，暂不能执行该命令；请等本次推理结束后再试。');

    commandCtx.commands.register({
      name: 'plasticize',
      description: '/plasticize <区间> <替代文本> | /plasticize hide <区间> | /plasticize clear（待写入队列，发送下一条消息时落盘）',
      input: { hint: '<区间> [替代文本] | hide <区间> | clear' },
      recordInput: false,
      handler: ({ agent, rawInput }) => {
        const session = agent?.session;
        if (session === undefined || session === null) return fail(new Error('这条命令需要一个会话'));
        if (busy(agent)) return fail(busyError());
        try {
          const parsed = parsePlasticizeCommand(rawInput);
          if (parsed.action === 'clear') {
            const cleared = clearUserProjections(session);
            return { kind: 'success', text: '已清空 ' + String(cleared) + ' 段待写入操作。' };
          }
          const result = queueUserProjection(session, parsed.interval, parsed.newText);
          return {
            kind: 'success',
            text: '已加入待写入队列：第 ' + String(result.queued) + ' 段（区间 ' + parsed.interval + '，' +
              (parsed.hide || parsed.newText.length === 0 ? '隐藏' : '替代 ' + JSON.stringify(parsed.newText.slice(0, 24))) +
              '）。发送下一条用户消息时写入；/plasticize clear 可清空。这些状态只在内存中，崩溃/关机即丢失。',
          };
        } catch (error) {
          return fail(error);
        }
      },
    });
    for (const op of ['lock', 'unlock']) {
      commandCtx.commands.register({
        name: op,
        description: op === 'lock'
          ? '把区间/全部/下一条用户消息纳入安全区：任何 plasticize 操作都不能命中'
          : '把区间/全部/下一条用户消息移出安全区',
        input: { hint: op === 'unlock' ? UNLOCK_HINT : SAFETY_HINT },
        recordInput: false,
        handler: async ({ agent, rawInput }) => {
          const session = agent?.session;
          if (session === undefined || session === null) return fail(new Error('这条命令需要一个会话'));
          try {
            const parsed = parseSafetyCommand(rawInput, op);
            // this 不需要竞态保护：消息尚未存在，模型无从命中；私有事件先于消息进入上下文。
            if (busy(agent) && parsed.mode !== 'this') return fail(busyError());
            let payload;
            let count;
            if (parsed.mode === 'range') {
              const seqs = resolveLockSeqs(session, parsed.interval);
              payload = { op, mode: 'range', seqs };
              count = seqs.length;
            } else if (parsed.mode === 'all') {
              payload = { op, mode: 'all' };
              count = session.surface.nodes.length;
            } else {
              payload = { op, mode: 'this', body: parsed.body };
              count = 1;
            }
            await appendSafetyRecord(session, payload);
            if (parsed.mode === 'this') await followupUserBody(agent, parsed.body);
            return {
              kind: 'success',
              text: '/' + op + '：' + (op === 'lock' ? '已纳入' : '已移出') + ' ' + String(count) +
                ' 条消息' + (parsed.mode === 'this' ? '，并已发送该用户消息。' : '。'),
            };
          } catch (error) {
            return fail(error);
          }
        },
      });
    }
  });
}